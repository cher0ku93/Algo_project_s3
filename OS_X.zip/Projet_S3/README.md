# Algo_project_s3
Projet L2 "Gestion agenda" 2023

Pour un bon fonctionnement du projet, suivez les instructions suivantes : 

Windows : 
  - Ouvrez Clion et creez un projet 'Projet_S3'
  - Créez les fichiers à l'identique. Tout les dossier ainsi que les .c/.h doivent être créer
  - remplacer les fichiers par ceux présent sur Github et lancez le run.

OS X : 
  - Téléchargez le fichier.zip 'OS_X'
  - Ouvrez le dans Clion
  - Si nécéssaire, configurez-le. En théorie, pas besoin.
  - Lancez le projet 
