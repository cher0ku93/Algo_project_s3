//
// Created by Ilyès, Diaby, Hippolyte
//

#ifndef PROJET_S3_MENU_THREE_H
#define PROJET_S3_MENU_THREE_H

//#include "../part_3/agenda.h"

int menu3();

#endif //PROJET_S3_MENU_THREE_H
