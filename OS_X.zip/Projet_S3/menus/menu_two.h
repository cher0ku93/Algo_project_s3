//
// Created by Ilyès K on 2023.
//

#ifndef PROJET_S3_MENU_TWO_H
#define PROJET_S3_MENU_TWO_H

#include "../part_1/cellules.h"
#include "../part_1/listes.h"
#include "../part_2/liste_2.h"

int menu2();

#endif //PROJET_S3_MENU_TWO_H
