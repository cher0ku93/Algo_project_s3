//
// Created by Ilyès K on 2023.
//

#ifndef PROJET_S3_MENU_ONE_H
#define PROJET_S3_MENU_ONE_H

#include "../part_1/cellules.h"
#include "../part_1/listes.h"
#include "menu_three.h"
#include "menu_two.h"

void menu_principal();
int menu1();
void back1();

#endif //PROJET_S3_MENU_ONE_H
